"""
The `home` function renders the index.html template and passes a list of the top 10 scores from the `Score` model, ordered by descending score.
"""

"""
The `register` function handles user registration. If the request method is POST, it creates a `CustomUserCreationForm` instance with the request POST data, and if the form is valid, it saves the user, logs them in, and creates a new `Score` object with the latest score submitted in the POST data. If the form is invalid, it prints the form errors to the console for debugging. If the request method is GET, it creates a new `CustomUserCreationForm` instance and renders the register.html template with the form.
"""

"""
The `submit_score` function handles the submission of a new score. If the request method is POST, it creates a new `Score` object with the user and the score submitted in the POST data, and returns a JSON response with a 'success' status. If the request method is not POST, it returns a JSON response with a 'fail' status.
"""

"""
The `save_score` function handles the saving of a new score. If the request method is POST, it loads the score data from the request body, stores the latest score in the session, and returns a JSON response with a 'success' status. If the request method is not POST, it returns a JSON response with a 'failed' status and a 400 HTTP status code.
"""
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Score
from .forms import CustomUserCreationForm
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Max
import json
from django.contrib.auth.models import User 
from django.urls import reverse

def home(request):
    top_scores = (Score.objects.values('user')
                  .annotate(max_score=Max('score'))
                  .order_by('-max_score')[:10])
    
    user_ids = [score['user'] for score in top_scores]
    users = User.objects.in_bulk(user_ids)
    
    for score in top_scores:
        score['user'] = users[score['user']]
    
    register_url = reverse('register')
    return render(request, 'index.html', {'scores': top_scores, 'register_url': register_url})

# def leaderboard(request):
#     top_scores = (Score.objects.values('user')
#                   .annotate(max_score=Max('score'))
#                   .order_by('-max_score')[:10])
    
#     user_ids = [score['user'] for score in top_scores]
#     users = User.objects.in_bulk(user_ids)
    
#     for score in top_scores:
#         score['user'] = users[score['user']]
    
#     return render(request, 'leaderboard.html', {'scores': top_scores})


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)

            # Submit the latest score
            score_value = request.POST.get('latest_score', 0)  # Get the latest score from POST data
            if score_value:
                Score.objects.create(user=user, score=score_value)

            return redirect('home') 
            # return JsonResponse({'status': 'success'})  # Return JSON response on success# Return JSON response on failure
    else:
        form = CustomUserCreationForm()
    return render(request, 'signup.html', {'form': form})

@login_required
def submit_score(request):
    if request.method == 'POST':
        score = request.POST['score']
        Score.objects.create(user=request.user, score=score)
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'fail'})



@csrf_exempt
def save_score(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        request.session['latest_score'] = data['score']
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'failed'}, status=400)